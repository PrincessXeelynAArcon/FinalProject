    document.getElementById("signupForm").addEventListener("submit", function(event) {
      event.preventDefault();
      let errors = 0;

      const fields = ["firstName", "lastName", "email", "password", "supportReason"];
      fields.forEach(id => {
        const input = document.getElementById(id);
        const error = document.getElementById(id + "Error");
        if (!input.value.trim()) {
          error.textContent = "Required";
          errors++;
        } else {
          error.textContent = "";
        }
      });

      const sex = document.querySelector("input[name='sex']:checked");
      const sexError = document.getElementById("sexError");
      if (!sex) {
        sexError.textContent = "Required";
        errors++;
      } else {
        sexError.textContent = "";
      }

      if (errors === 0) 
      {
        localStorage.setItem("firstName", document.getElementById("firstName").value);
        localStorage.setItem("lastName", document.getElementById("lastName").value);
        localStorage.setItem("email", document.getElementById("email").value);
        localStorage.setItem("sex", sex.value);
        localStorage.setItem("supportReason", document.getElementById("supportReason").value);
        window.location.href = "profile.html";
      }